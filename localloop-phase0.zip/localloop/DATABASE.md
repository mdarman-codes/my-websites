# Database

PostgreSQL 13+.

## Conventions
- Primary keys: `uuid DEFAULT gen_random_uuid()`
- Timestamps: `timestamptz`, UTC. Sessions are set to UTC by the pool.
- `updated_at` columns use the `set_updated_at()` trigger from migration 0000.
- Relationships are tables with foreign keys, not JSON.

## Migrations
Files in `apps/api/migrations/` named `NNNN_description.sql`. `npm run db:migrate` applies pending files in order, each in a transaction, under an advisory lock. Applied files are checksummed; editing one is an error. Add a new file instead.

| File | Contents | Status |
|---|---|---|
| 0000_foundation.sql | `citext`, `set_updated_at()` | NOT TESTED |

Domain tables (users, businesses, inventory, reservations, ...) arrive in Phases 1 to 5.
