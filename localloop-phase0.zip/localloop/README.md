# LocalLoop

> आपका मोहल्ला। बस एक सर्च दूर। (Your neighbourhood. One search away.)

Hyperlocal product discovery, branch-level inventory, store reservations, and retailer SaaS subscriptions for India. Pilot region: West Bengal.

## Status

**Phase 0 (foundation): written, NOT yet built or run.** The code was authored in an environment with no network access and no PostgreSQL, so dependencies were never installed and no test has run. See TESTING.md for the honest status of each check.

## Requirements

- Node.js 22+ and npm 10+
- PostgreSQL 13+ (PostGIS is needed from Phase 3). `docker compose up -d db` starts a local one.

## Quick start

```bash
npm install
cp .env.example .env          # then edit DATABASE_URL if needed
docker compose up -d db       # local database (optional if you have your own)
npm run build -w packages/shared
npm run db:migrate
npm run dev:api               # http://localhost:4000/api/v1/health
npm run dev:web               # http://localhost:5173
```

## Commands

| Command | What it does |
|---|---|
| `npm run build` | Build shared, api, web (in that order) |
| `npm run typecheck` | Type-check every workspace |
| `npm test` | Run tests |
| `npm run lint` | ESLint |
| `npm run db:migrate` | Apply pending SQL migrations |

## Layout

```
packages/shared   Zod schemas and enums used by api and web
apps/api          Express modular monolith + SQL migrations
apps/web          React + Vite + Tailwind (Hindi-first)
```

Other docs: ARCHITECTURE.md, DATABASE.md, API.md, SECURITY.md, DEPLOYMENT.md, TESTING.md.
