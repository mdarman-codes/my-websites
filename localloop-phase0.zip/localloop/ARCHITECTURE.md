# Architecture

## Style
Modular monolith. One API process, one PostgreSQL database. No microservices.

## Workspaces
- `packages/shared`: Zod schemas, role names and API error shape. Built to `dist/` and imported by api and web.
- `apps/api`: Express 5, pino logging, `pg` connection pool, SQL-file migrations.
- `apps/web`: React 18, Vite, Tailwind 3, TanStack Query. All UI text comes from `src/i18n/locales/*.json`.

## Planned API modules (added per phase)
auth, businesses, catalogue, inventory, discovery, reservations, fulfilment, billing, admin, notifications, audit.

## Decisions
| Decision | Choice | Why |
|---|---|---|
| Migrations | Plain SQL files + small runner | Version-controlled, reviewable, ORM-independent |
| Query layer | Decided in Phase 1 (Drizzle or typed raw SQL) | Avoids two sources of truth before tables exist |
| Background jobs | Postgres-backed queue (planned: pg-boss) | Reservation expiry without Redis in the MVP |
| Geo search | PostGIS `geography` + GiST index (Phase 3) | Correct distance and index support |
| Auth | Email + password, httpOnly cookie sessions (Phase 1) | Phone OTP later, needs an SMS provider |
| Env | Validated with Zod at startup; fail fast | Misconfiguration never reaches runtime |

## Inventory safety (design, Phase 2/4)
`on_hand` and `reserved` per branch, `CHECK (on_hand >= reserved)`, conditional `UPDATE` inside one transaction, unique idempotency key per customer for reservations, price snapshots on reservation items.
