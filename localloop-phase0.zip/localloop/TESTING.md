# Testing

Never treat a check as passed unless it has actually run.

## Phase 0 tests (written)
- `apps/api/test/health.test.ts`: liveness, readiness 200/503, JSON 404, no `x-powered-by`, CORS allow-list, request id
- `apps/api/test/env.test.ts`: defaults, fail-fast, no secret values in error text

## Status
| Check | Status |
|---|---|
| Unit and API tests | NOT TESTED |
| Type check | NOT TESTED |
| Lint | NOT TESTED |
| Production build | NOT TESTED |
| Migration against PostgreSQL | NOT TESTED |
| Mobile viewport / end-to-end | NOT TESTED |

Run: `npm run typecheck && npm run lint && npm test && npm run build`
