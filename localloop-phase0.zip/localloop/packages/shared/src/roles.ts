import { z } from "zod";

/** The four role-based experiences. Authorisation is always enforced on the server. */
export const USER_ROLES = ["customer", "shopkeeper", "delivery_partner", "admin"] as const;

export const userRoleSchema = z.enum(USER_ROLES);
export type UserRole = z.infer<typeof userRoleSchema>;
