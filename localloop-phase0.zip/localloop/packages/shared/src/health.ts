import { z } from "zod";

export const healthResponseSchema = z.object({
  status: z.literal("ok"),
  version: z.string(),
  timestamp: z.string().datetime(),
  uptimeSeconds: z.number().int().nonnegative(),
});
export type HealthResponse = z.infer<typeof healthResponseSchema>;

export const readyResponseSchema = z.object({
  status: z.enum(["ready", "degraded"]),
  checks: z.object({ database: z.enum(["up", "down"]) }),
  timestamp: z.string().datetime(),
});
export type ReadyResponse = z.infer<typeof readyResponseSchema>;

/** Standard error body for every API error. Messages never include internals. */
export const apiErrorSchema = z.object({
  error: z.object({ code: z.string(), message: z.string() }),
});
export type ApiError = z.infer<typeof apiErrorSchema>;
