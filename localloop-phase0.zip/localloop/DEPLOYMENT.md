# Deployment

**Not deployed. No deployment has been performed or tested.**

## Requirements
Node 22, PostgreSQL 13+ (PostGIS from Phase 3), HTTPS in front of the API.

## Steps (untested)
1. Set environment variables from `.env.example` in the host's secret store.
2. `npm ci && npm run build`
3. `npm run db:migrate` (needs `DATABASE_URL`)
4. `npm run start -w apps/api`
5. Serve `apps/web/dist` as static files.

## Notes
- Behind a reverse proxy, set Express `trust proxy` before enabling rate limiting (Phase 7).
- Backups, error monitoring and restore drills are Phase 7.
