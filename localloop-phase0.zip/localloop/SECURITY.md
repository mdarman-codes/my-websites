# Security

## In place (Phase 0, unverified until tests run)
- `helmet` headers; `x-powered-by` disabled
- CORS allow-list from `CORS_ALLOWED_ORIGINS`
- JSON body limit 100 kb
- Environment validated at startup; error messages never print values
- Log redaction for authorization, cookie and set-cookie headers
- Generic 500 responses; details only in server logs
- `.env` is git-ignored; only `.env.example` is committed

## Not yet implemented
Authentication, role and ownership checks, rate limiting, CSRF, file-upload validation, audit logging, payment webhook verification. These are scheduled in Phases 1, 2, 5 and 7. Nothing in this repo should be treated as production-secure yet.

## Rules
- No private keys in `apps/web`. Everything bundled there is public.
- Never request or store UPI PINs.
- Authorise every protected operation on the server.
