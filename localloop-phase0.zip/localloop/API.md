# API

Base path: `/api/v1`. JSON only.

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | /health | none | Liveness. 200 with `status`, `version`, `timestamp`, `uptimeSeconds` |
| GET | /health/ready | none | Readiness. 200 if database reachable, 503 otherwise |

## Errors
```json
{ "error": { "code": "not_found", "message": "Not found" } }
```
Messages never contain internals. Every response carries an `x-request-id` header that also appears in logs.
