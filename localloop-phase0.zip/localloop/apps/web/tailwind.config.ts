import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        forest: { DEFAULT: "#0F3D2A", soft: "#2C5A44" },
        cream: { DEFAULT: "#FBF6EA", deep: "#F1EAD6" },
        lime: { DEFAULT: "#B6E34A" },
        charcoal: { DEFAULT: "#1F2421", soft: "#5A625D" },
      },
      fontFamily: {
        // Devanagari first so Hindi glyphs use Noto Sans Devanagari; Latin text falls back to Inter.
        sans: ['"Noto Sans Devanagari"', "Inter", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
} satisfies Config;
