import { useQuery } from "@tanstack/react-query";
import { readyResponseSchema } from "@localloop/shared";
import { t, type MessageKey } from "./i18n";

// A 503 still carries a valid body, so we parse the body rather than trusting res.ok.
async function fetchReadiness() {
  const res = await fetch("/api/v1/health/ready");
  return readyResponseSchema.parse(await res.json());
}

export default function App() {
  const readiness = useQuery({ queryKey: ["health", "ready"], queryFn: fetchReadiness, retry: false });

  let messageKey: MessageKey = "status.checking";
  let dot = "bg-charcoal-soft";
  if (readiness.isError) {
    messageKey = "status.unreachable";
    dot = "bg-red-700";
  } else if (readiness.data) {
    const ready = readiness.data.status === "ready";
    messageKey = ready ? "status.ready" : "status.degraded";
    dot = ready ? "bg-lime" : "bg-red-700";
  }

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col px-5 py-10">
      <p className="text-lg font-semibold tracking-tight text-forest">LocalLoop</p>
      <h1 className="mt-8 text-3xl font-bold leading-snug text-forest">{t("app.tagline")}</h1>

      <section aria-labelledby="status-heading" className="mt-12 rounded-xl border border-forest/20 bg-white p-5">
        <h2 id="status-heading" className="text-sm font-medium text-charcoal-soft">
          {t("status.heading")}
        </h2>
        <p className="mt-3 flex items-start gap-3 text-base" role="status" aria-live="polite">
          <span aria-hidden="true" className={`mt-2 h-2.5 w-2.5 shrink-0 rounded-full ${dot}`} />
          <span>{t(messageKey)}</span>
        </p>
        <button
          type="button"
          onClick={() => void readiness.refetch()}
          disabled={readiness.isFetching}
          className="mt-5 min-h-11 rounded-lg bg-forest px-4 text-base font-medium text-cream disabled:opacity-60"
        >
          {t("action.retry")}
        </button>
      </section>
    </main>
  );
}
