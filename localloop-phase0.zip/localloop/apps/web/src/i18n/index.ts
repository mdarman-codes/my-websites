import hi from "./locales/hi.json";

// Every user-facing string lives in a locale file. Components call t("key") and never
// contain literal text. To add a language: add locales/<code>.json with the same keys,
// register it below, and expose a locale switcher (Phase 6).
const locales = { hi } as const;

export type Locale = keyof typeof locales;
export type MessageKey = keyof typeof hi;

let current: Locale = "hi";

export function setLocale(locale: Locale): void {
  current = locale;
}

export function t(key: MessageKey): string {
  return locales[current][key];
}
