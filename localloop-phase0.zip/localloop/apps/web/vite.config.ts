import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// In development the browser talks to Vite, which forwards /api to the API server.
// No secrets or private keys belong in this app: everything bundled here is public.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { "/api": "http://localhost:4000" },
  },
});
