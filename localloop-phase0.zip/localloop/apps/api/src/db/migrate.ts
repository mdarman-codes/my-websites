import { createHash } from "node:crypto";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { Logger } from "pino";
import type pg from "pg";
import { loadEnv } from "../config/env.js";
import { createLogger } from "../lib/logger.js";
import { createPool } from "./pool.js";

const MIGRATIONS_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../migrations");
const ADVISORY_LOCK_KEY = 726001; // app-specific; stops two deploys migrating at once
const FILE_PATTERN = /^\d{4}_[a-z0-9_]+\.sql$/;

/**
 * Applies pending *.sql files in filename order, each inside one transaction.
 * Applied files are recorded with a checksum; editing an applied file is an error.
 */
export async function runMigrations(
  pool: pg.Pool,
  log: Pick<Logger, "info">,
  dir: string = MIGRATIONS_DIR,
): Promise<string[]> {
  const client = await pool.connect();
  const appliedNow: string[] = [];
  try {
    await client.query("SELECT pg_advisory_lock($1)", [ADVISORY_LOCK_KEY]);
    await client.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        filename   text PRIMARY KEY,
        checksum   text NOT NULL,
        applied_at timestamptz NOT NULL DEFAULT now()
      )`);

    const files = (await readdir(dir)).filter((f) => FILE_PATTERN.test(f)).sort();
    const { rows } = await client.query<{ filename: string; checksum: string }>(
      "SELECT filename, checksum FROM schema_migrations",
    );
    const applied = new Map(rows.map((r) => [r.filename, r.checksum]));

    for (const file of files) {
      const sql = await readFile(path.join(dir, file), "utf8");
      const checksum = createHash("sha256").update(sql).digest("hex");
      const previous = applied.get(file);
      if (previous !== undefined) {
        if (previous !== checksum) {
          throw new Error(`Migration ${file} was changed after it was applied. Add a new migration instead.`);
        }
        continue;
      }
      log.info({ file }, "applying migration");
      try {
        await client.query("BEGIN");
        await client.query(sql);
        await client.query("INSERT INTO schema_migrations (filename, checksum) VALUES ($1, $2)", [file, checksum]);
        await client.query("COMMIT");
        appliedNow.push(file);
      } catch (err) {
        await client.query("ROLLBACK");
        throw err;
      }
    }
    return appliedNow;
  } finally {
    await client.query("SELECT pg_advisory_unlock($1)", [ADVISORY_LOCK_KEY]).catch(() => undefined);
    client.release();
  }
}

async function main(): Promise<void> {
  const env = loadEnv();
  const log = createLogger(env);
  const pool = createPool(env);
  try {
    const applied = await runMigrations(pool, log);
    log.info({ applied }, applied.length ? "migrations complete" : "database already up to date");
  } finally {
    await pool.end();
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((err: unknown) => {
    console.error(err instanceof Error ? err.message : err);
    process.exit(1);
  });
}
