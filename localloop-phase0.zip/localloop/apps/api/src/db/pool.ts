import pg from "pg";
import type { Env } from "../config/env.js";

/** All sessions run in UTC. Timestamps are stored as timestamptz. */
export function createPool(env: Pick<Env, "DATABASE_URL" | "DATABASE_POOL_MAX">): pg.Pool {
  return new pg.Pool({
    connectionString: env.DATABASE_URL,
    max: env.DATABASE_POOL_MAX,
    connectionTimeoutMillis: 5_000,
    idleTimeoutMillis: 30_000,
    options: "-c timezone=UTC -c statement_timeout=15000",
  });
}

/** Returns true only if a trivial query succeeds. Never throws. */
export async function checkDatabase(pool: Pick<pg.Pool, "query">): Promise<boolean> {
  try {
    await pool.query("SELECT 1");
    return true;
  } catch {
    return false;
  }
}
