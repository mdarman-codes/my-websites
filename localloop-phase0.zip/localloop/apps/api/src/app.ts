import { randomUUID } from "node:crypto";
import cors from "cors";
import express, { type ErrorRequestHandler, type Express } from "express";
import helmet from "helmet";
import type { Logger } from "pino";
import { pinoHttp } from "pino-http";
import type { ApiError, HealthResponse, ReadyResponse } from "@localloop/shared";

export interface AppDeps {
  logger: Logger;
  corsAllowedOrigins: string[];
  version: string;
  checkDatabase: () => Promise<boolean>;
}

const REQUEST_ID_PATTERN = /^[\w-]{8,64}$/;

export function createApp(deps: AppDeps): Express {
  const app = express();
  const allowedOrigins = new Set(deps.corsAllowedOrigins);

  app.disable("x-powered-by");

  app.use(
    pinoHttp({
      logger: deps.logger,
      genReqId: (req, res) => {
        const incoming = req.headers["x-request-id"];
        const id = typeof incoming === "string" && REQUEST_ID_PATTERN.test(incoming) ? incoming : randomUUID();
        res.setHeader("x-request-id", id);
        return id;
      },
    }),
  );
  app.use(helmet());
  app.use(
    cors({
      // Requests with no Origin (curl, server-to-server) pass; browsers must be on the allow-list.
      origin: (origin, callback) => callback(null, !origin || allowedOrigins.has(origin)),
      credentials: true,
    }),
  );
  app.use(express.json({ limit: "100kb" }));

  const v1 = express.Router();

  // Liveness: the process is up. No dependencies are checked.
  v1.get("/health", (_req, res) => {
    const body: HealthResponse = {
      status: "ok",
      version: deps.version,
      timestamp: new Date().toISOString(),
      uptimeSeconds: Math.floor(process.uptime()),
    };
    res.json(body);
  });

  // Readiness: the process can serve traffic (database reachable).
  v1.get("/health/ready", async (_req, res) => {
    const dbUp = await deps.checkDatabase();
    const body: ReadyResponse = {
      status: dbUp ? "ready" : "degraded",
      checks: { database: dbUp ? "up" : "down" },
      timestamp: new Date().toISOString(),
    };
    res.status(dbUp ? 200 : 503).json(body);
  });

  app.use("/api/v1", v1);

  app.use((_req, res) => {
    const body: ApiError = { error: { code: "not_found", message: "Not found" } };
    res.status(404).json(body);
  });

  const onError: ErrorRequestHandler = (err, req, res, _next) => {
    req.log.error({ err }, "unhandled error");
    const body: ApiError = { error: { code: "internal_error", message: "Something went wrong" } };
    res.status(500).json(body);
  };
  app.use(onError);

  return app;
}
