import { createApp } from "./app.js";
import { loadEnv, type Env } from "./config/env.js";
import { checkDatabase, createPool } from "./db/pool.js";
import { createLogger } from "./lib/logger.js";

let env: Env;
try {
  env = loadEnv();
} catch (err) {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
}

const logger = createLogger(env);
const pool = createPool(env);
pool.on("error", (err) => logger.error({ err }, "idle database client error"));

const app = createApp({
  logger,
  corsAllowedOrigins: env.CORS_ALLOWED_ORIGINS,
  version: env.APP_VERSION,
  checkDatabase: () => checkDatabase(pool),
});

const server = app.listen(env.PORT, () => logger.info({ port: env.PORT }, "api listening"));

function shutdown(signal: string): void {
  logger.info({ signal }, "shutting down");
  const force = setTimeout(() => process.exit(1), 10_000);
  force.unref();
  server.close(() => {
    pool
      .end()
      .catch((err: unknown) => logger.error({ err }, "error closing database pool"))
      .finally(() => process.exit(0));
  });
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
