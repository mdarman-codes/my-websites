-- 0000_foundation: shared database conventions used by every later table.
--
-- Conventions (see DATABASE.md):
--   * Primary keys: uuid DEFAULT gen_random_uuid()   (built in since PostgreSQL 13)
--   * Timestamps:   timestamptz, always UTC
--   * updated_at:   maintained by the set_updated_at() trigger below
--
-- PostGIS is NOT enabled here. It is added in the Phase 3 migration for nearby search.

CREATE EXTENSION IF NOT EXISTS citext;  -- case-insensitive email addresses

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
