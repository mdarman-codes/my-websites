import { pino } from "pino";
import request from "supertest";
import { describe, expect, it } from "vitest";
import { healthResponseSchema, readyResponseSchema } from "@localloop/shared";
import { createApp } from "../src/app.js";

const ORIGIN = "http://localhost:5173";
const makeApp = (dbUp: boolean) =>
  createApp({
    logger: pino({ level: "silent" }),
    corsAllowedOrigins: [ORIGIN],
    version: "test",
    checkDatabase: async () => dbUp,
  });

describe("health endpoints", () => {
  it("GET /api/v1/health returns a valid liveness body", async () => {
    const res = await request(makeApp(true)).get("/api/v1/health");
    expect(res.status).toBe(200);
    expect(healthResponseSchema.safeParse(res.body).success).toBe(true);
  });

  it("GET /api/v1/health/ready is 200 when the database is up", async () => {
    const res = await request(makeApp(true)).get("/api/v1/health/ready");
    expect(res.status).toBe(200);
    expect(readyResponseSchema.parse(res.body).checks.database).toBe("up");
  });

  it("GET /api/v1/health/ready is 503 when the database is down", async () => {
    const res = await request(makeApp(false)).get("/api/v1/health/ready");
    expect(res.status).toBe(503);
    expect(readyResponseSchema.parse(res.body).status).toBe("degraded");
  });
});

describe("app hardening", () => {
  it("returns a JSON 404 for unknown routes", async () => {
    const res = await request(makeApp(true)).get("/nope");
    expect(res.status).toBe(404);
    expect(res.body.error.code).toBe("not_found");
  });

  it("does not advertise the framework", async () => {
    const res = await request(makeApp(true)).get("/api/v1/health");
    expect(res.headers["x-powered-by"]).toBeUndefined();
  });

  it("reflects an allowed CORS origin only", async () => {
    const ok = await request(makeApp(true)).get("/api/v1/health").set("Origin", ORIGIN);
    expect(ok.headers["access-control-allow-origin"]).toBe(ORIGIN);
    const bad = await request(makeApp(true)).get("/api/v1/health").set("Origin", "https://evil.example");
    expect(bad.headers["access-control-allow-origin"]).toBeUndefined();
  });

  it("sets a request id header", async () => {
    const res = await request(makeApp(true)).get("/api/v1/health");
    expect(res.headers["x-request-id"]).toBeTruthy();
  });
});
