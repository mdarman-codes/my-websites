import { describe, expect, it } from "vitest";
import { loadEnv } from "../src/config/env.js";

const valid = { DATABASE_URL: "postgres://u:secret-pass@localhost:5432/db" };

describe("loadEnv", () => {
  it("applies defaults and parses the CORS list", () => {
    const env = loadEnv({ ...valid, CORS_ALLOWED_ORIGINS: "http://a.test, http://b.test" });
    expect(env.PORT).toBe(4000);
    expect(env.CORS_ALLOWED_ORIGINS).toEqual(["http://a.test", "http://b.test"]);
  });

  it("fails fast when DATABASE_URL is missing", () => {
    expect(() => loadEnv({})).toThrow(/DATABASE_URL/);
  });

  it("never echoes secret values in the error message", () => {
    let message = "";
    try {
      loadEnv({ DATABASE_URL: "mysql://u:secret-pass@host/db" });
    } catch (err) {
      message = String(err);
    }
    expect(message).toContain("DATABASE_URL");
    expect(message).not.toContain("secret-pass");
  });
});
